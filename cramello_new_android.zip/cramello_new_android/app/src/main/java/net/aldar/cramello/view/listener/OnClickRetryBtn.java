package net.aldar.cramello.view.listener;

public interface OnClickRetryBtn {

    void retry();
}
