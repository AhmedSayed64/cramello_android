package net.aldar.cramello.services.backPressed;

/**
 * Created by shahabuddin on 5/16/2017.
 */
public interface OnBackPressListener {

    public boolean onBackPressed();
}
